
# SnackSelector
An elementary website using Nodejs, Express and other nodejs packages

![Image of Main page](https://raw.githubusercontent.com/Tarokan/SnackSelector/master/screenshots/mainpage.PNG)

## Todo
+ sort snacklist by alphabetical order
+ add filtering options for snacklist
+ add option to suggest a snack not on the snacklist

## Site Layout and Features
#### Survey
The survey poses the users three basic questions and a "check all" question that helps the site identify the user's snack preferences.
